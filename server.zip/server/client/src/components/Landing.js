import React from "react";

const Landing = () => {
	return (
		<div className="center">
			<h1>InstaMassMail</h1>
			Collect feedback from users instantly
		</div>
	);
};

export default Landing;
