export default [
	{label: 'Campaign Title', name: 'title', noValueError: 'Blank title is not allowed.'},
	{label: 'Subject Line', name: 'subject', noValueError:'Blank subject is not allowed.'},
	{label: 'InstaMassMail Body', name:'body', noValueError:'Type something to proceed.'},
	{label:'Recipient List', name: 'recipients', noValueError:'Empty Email lists is not allowed.'}
]