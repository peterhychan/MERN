module.exports = {
	googleClientID:
		"368963944728-l0odibv6ahtfu6u9gcqefq2iiu3jv134.apps.googleusercontent.com",
	googleClientSecret: "G5lNrjP8UyoVWoSHt4yc5Qf5",
	mongoURI: "mongodb://hchan80:hchan80@ds123003.mlab.com:23003/instamassmail",
	cookieKey: "flasflasfcnlaajaliiarhlfafl",
	stripePublishableKey: "pk_test_x3LgzwCx0th9Tf78luZTLqMc",
	stripeSecretKey: "sk_test_5l0aT3Z62t8QAUvfLXPRKKNT",
	sendGridKey:"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",
	redirectDomain:"http://localhost:3000"
};
